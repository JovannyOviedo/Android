package com.example.prestamos;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static List<String> nombreList= new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v)
    {
        EditText etNombre = findViewById(R.id.etNombre);
        Intent intent = new Intent(this, SegundaActivity.class);
        intent.putExtra("valor",etNombre.getText().toString());
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId())
        {
            case R.id.mnNuevo_prestamo:
                //Toast.makeText(this, "Nuevo prestamo", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, TerceraActivity.class);
                //startActivity(intent);
                startActivityForResult(intent,4444);
                break;
            case R.id.mnNuevo_Cliente:
                Intent intent1 = new Intent(this, SolicitudActivity.class);
                startActivityForResult(intent1,4444);
                break;
            case R.id.mnVer_Cliente:
                Toast.makeText(this, "Ver Cliente", Toast.LENGTH_SHORT).show();
                break;
            case R.id.mnver_Cliente:
                Toast.makeText(this, "Ver Cliente", Toast.LENGTH_SHORT).show();
                break;
            case R.id.mnAcerca_De:
                Toast.makeText(this, "Sobre", Toast.LENGTH_SHORT).show();
                break;
        }
        //Toast.makeText(this, "Menus", Toast.LENGTH_SHORT).show();
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
      if(requestCode==4444)
      {
        if(resultCode==RESULT_CANCELED)
            Toast.makeText(this, "Cancelar", Toast.LENGTH_SHORT).show();
        else {
            String valor =  data.getExtras().getString("valor");
            Toast.makeText(this, "Ok " + valor, Toast.LENGTH_SHORT).show();
        }
      }
      //else if(requestCode==7858)
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.contextual,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }
}
